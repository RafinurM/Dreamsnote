import { create, type StateCreator } from "zustand";
import type { IUser } from "../types/user";
import { user } from "../shared/api/mock";

interface IInitialState {
  user: IUser | null;
  isAuth: boolean;
}

interface IUserStore extends IInitialState {}

const initialState: IInitialState = {
  user: null,
  isAuth: false,
};

const userStore: StateCreator<IUserStore> = () => ({
  ...initialState,
});

export const useUserStore = create<IUserStore>()(userStore);

export const useUser = () => useUserStore((state) => state.user);
export const useIsAuth = () => useUserStore((state) => state.isAuth);
