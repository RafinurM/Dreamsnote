const siteConfig = {
    title: 'DREAMERS',
    adv: 'dream',
    buttons: {
        login: 'Войти',
        
    },
}

export default siteConfig