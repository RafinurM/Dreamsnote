import { create, type StateCreator } from "zustand";

interface IActions {
    changeCover: () => void;
    changeModalStatus: () => void;
}

interface IInitialState {
    coverIsActive: boolean,
    modalIsOpen: boolean,
}

interface IAppStore extends IInitialState, IActions { }

const initialState: IInitialState = {
    coverIsActive: true,
    modalIsOpen: false,
}

const appStore: StateCreator<IAppStore> = ((set) => ({
    ...initialState,
    changeCover: () => set((state) => ({ coverIsActive: !state.coverIsActive })),
    changeModalStatus: () => set((state) => ({ modalIsOpen: !state.modalIsOpen }))

}));

export const useAppStore = create<IAppStore>()(appStore);

export const useCoverIsActive = () => useAppStore(state => state.coverIsActive);
export const useModalStatus = () => useAppStore(state => state.modalIsOpen);
export const changeCover = () => useAppStore.getState().changeCover;
export const changeModalStatus = () => useAppStore.getState().changeModalStatus;

