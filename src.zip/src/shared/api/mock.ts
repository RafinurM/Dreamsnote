import type { IBackgroundArticle } from "../../types/additional";
import type { IArticle } from "../../types/article";
import type { IDream } from "../../types/dreams";
import type { IUser } from "../../types/user";


export const dreams: IDream[] = [
    {
        name: 'Второй сон',
        text: ' Et ex quod nam doloribus fugit illo similique eius officia eum labore, ducimus quasi sint vel aut aspernatur facilis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem magnam aliquid omnis laboriosam reprehenderit sapiente quia deleniti at beatae explicabo quis dolorem nulla ad excepturi quam, odit sed itaque impedit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus vitae mollitia unde facere corporis ipsum repudiandae deleniti ab, consequatur commodi sequi, voluptates magnam nostrum quos veniam magni et hic iste.',
        created_at: new Date(),
        id: '201',
        author: 'tester et',
        likes: [],
    },
    {
        name: 'Третий сон',
        text: `За каждым из уровней закреплена своя зона и ответственности и, как видите, все они сильно ориентированы на бизнес. Кроме того, у них ступенчатая иерархия, как показано на следующей картинке. Она строится так, чтобы получился понятный однонаправленный поток данных, что значительно повышает удобство работы с приложением.`,
        created_at: new Date(),
        id: '202',
        author: 'tetststs',
        likes: [],
    },
    {
        name: 'test dream',
        text: `Et ex quod nam doloribus fugit illo similique eius officia eum labore, ducimus quasi sint vel aut aspernatur facilis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem magnam aliquid omnis laboriosam reprehenderit sapiente quia deleniti at beatae explicabo quis dolorem nulla ad excepturi quam, odit sed itaque impedit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus vitae mollitia unde facere corporis ipsum repudiandae deleniti ab, consequatur commodi sequi, voluptates magnam nostrum quos veniam magni et hic iste.Et ex quod nam doloribus fugit illo similique eius officia eum labore, ducimus quasi sint vel aut aspernatur facilis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem magnam aliquid omnis laboriosam reprehenderit sapiente quia deleniti at beatae explicabo quis dolorem nulla ad excepturi quam, odit sed itaque impedit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus vitae mollitia unde facere corporis ipsum repudiandae deleniti ab, consequatur commodi sequi, voluptates magnam nostrum quos veniam magni et hic iste.Et ex quod nam doloribus fugit illo similique eius officia eum labore, ducimus quasi sint vel aut aspernatur facilis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem magnam aliquid omnis laboriosam reprehenderit sapiente quia deleniti at beatae explicabo quis dolorem nulla ad excepturi quam, odit sed itaque impedit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus vitae mollitia unde facere corporis ipsum repudiandae deleniti ab, consequatur commodi sequi, voluptates magnam nostrum quos veniam magni et hic iste.Et ex quod nam doloribus fugit illo similique eius officia eum labore, ducimus quasi sint vel aut aspernatur facilis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem magnam aliquid omnis laboriosam reprehenderit sapiente quia deleniti at beatae explicabo quis dolorem nulla ad excepturi quam, odit sed itaque impedit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus vitae mollitia unde facere corporis ipsum repudiandae deleniti ab, consequatur commodi sequi, voluptates magnam nostrum quos veniam magni et hic iste.Et ex quod nam doloribus fugit illo similique eius officia eum labore, ducimus quasi sint vel aut aspernatur facilis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem magnam aliquid omnis laboriosam reprehenderit sapiente quia deleniti at beatae explicabo quis dolorem nulla ad excepturi quam, odit sed itaque impedit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus vitae mollitia unde facere corporis ipsum repudiandae deleniti ab, consequatur commodi sequi, voluptates magnam nostrum quos veniam magni et hic iste.Et ex quod nam doloribus fugit illo similique eius officia eum labore, ducimus quasi sint vel aut aspernatur facilis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem magnam aliquid omnis laboriosam reprehenderit sapiente quia deleniti at beatae explicabo quis dolorem nulla ad excepturi quam, odit sed itaque impedit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus vitae mollitia unde facere corporis ipsum repudiandae deleniti ab, consequatur commodi sequi, voluptates magnam nostrum quos veniam magni et hic iste.Et ex quod nam doloribus fugit illo similique eius officia eum labore, ducimus quasi sint vel aut aspernatur facilis! Lorem ipsum, dolor sit amet consectetur adipisicing elit. Autem magnam aliquid omnis laboriosam reprehenderit sapiente quia deleniti at beatae explicabo quis dolorem nulla ad excepturi quam, odit sed itaque impedit! Lorem ipsum dolor sit amet consectetur adipisicing elit. Minus vitae mollitia unde facere corporis ipsum repudiandae deleniti ab, consequatur commodi sequi, voluptates magnam nostrum quos veniam magni et hic iste.`,
        created_at: new Date(),
        id: '204',
        likes: [],
    },
    {
        name: 'Мой сон',
        text: 'Это был удивительный сон. Мне снилось что я видел керасивейший сад и цветущие деревья. Вдалеке было что то расплывчатое, но я знал - это горы. Меня наполняла радость и я оказался возле качелей. Вдруг пейзаж поменялся и я оказался во дворе дома, рядом были уже другие качели и тут произошло пробуждение. ',
        created_at: new Date(),
        id: '203',
        likes: [],
    },
    {
        name: 'Мой сон2',
        text: 'Это был удивительный сон. Мне снилось что я видел керасивейший сад и цветущие деревья. Вдалеке было что то расплывчатое, но я знал - это горы. Меня наполняла радость и я оказался возле качелей. Вдруг пейзаж поменялся и я оказался во дворе дома, рядом были уже другие качели и тут произошло пробуждение. ',
        created_at: new Date(),
        id: '205',
        likes: [],
    },
    {
        name: 'Мой сон3',
        text: 'Это был удивительный сон. Мне снилось что я видел керасивейший сад и цветущие деревья. Вдалеке было что то расплывчатое, но я знал - это горы. Меня наполняла радость и я оказался возле качелей. Вдруг пейзаж поменялся и я оказался во дворе дома, рядом были уже другие качели и тут произошло пробуждение. ',
        created_at: new Date(),
        id: '206',
        likes: [],
    },

]

export const articles: IArticle[] = [
    {
        name: 'Сколько человек спит за жизнь?',
        content: 'Средняя продолжительность жизни человека — около 75 лет. Рекомендуемая норма сна — 8 часов в сутки. \nПосчитаем: \n8 часов × 365 дней = 2920 часов сна в год \n2920 часов × 75 лет = 219 000 часов \nЕсли перевести это в годы: \n219 000 часов ÷ 24 часа = примерно 25 лет человек проводит во сне.',
        id: '12'
    },
    {
        name: 'Что такое сон?',
        content: `Сон — это физиологическое состояние, противоположное состоянию бодрствования, при котором снижается реакция организма на окружающий мир. Также словом «сон» называют последовательность образов, которые формируются во время сна и человек может помнить, — сновидение.`,
        id: '5'
    },
    {
        name: 'Рекомендации по улучшению качества сна',
        content: `Для улучшения качества сна рекомендуется создать комфортные условия, соблюдать ритуалы перед сном, правильно питаться и избегать некоторых напитков. Если проблемы со сном сохраняются, стоит обратиться к врачу.`,
        id: '15'
    },
    {
        name: 'Всем ли снятся сны',
        content: `Часто последнее, что помнят люди при пробуждении, — это момент отхода ко сну, и думают, что их ночь прошла без сновидений. На самом деле, по словам врача-сомнолога, профессора, д.м.н. Романа Бузунова, в условиях достаточного сна сновидения видят все люди. Другое дело, что не всегда человек их запоминает. Специалист рассказывает: «Люди часто не помнят сны, когда просыпаются не в REM-фазе. Но если на полисомнографии распознать фазу быстрого сна и в такой момент разбудить человека, он обязательно расскажет, что ему снилось».
Незрячие люди тоже «видят» сны, но они наполнены не столько зрительными, сколько слуховыми и тактильными образами. Это подтверждает, что сновидения — не случайные картинки, а механизм, который мозг использует для обработки полученной за день информации.
Если в случае со взрослыми про сновидения можно узнать из первых уст, то с новорожденными детьми и животными сделать это несколько сложнее. И все же специалистам удалось выяснить, что они тоже видят сны.
Ученые отмечают, что мы начинаем видеть сны даже не в младенчестве, а еще до появления на свет. Активность мозга, характерная для REM-фазы сна, регистрируется у детей, начиная с 30 недели после зачатия. В это время они, скорее всего, видят сновидения о том единственном опыте, который у них есть — ощущениях в утробе матери.
На то, что животные тоже видят сны, указывают многие косвенные признаки. Коты и собаки во сне шевелят лапами и усами, выпускают когти, иногда даже рычат. В 1959 году французский ученый Мишель Жуве обнаружил, что удаление части ствола головного мозга у кошки отключало защитную функцию обездвиживания тела во время REM-фазы сна. В итоге, вместо того чтобы лежать на месте, кошки начинали беспорядочно двигаться и вели себя агрессивно. Это натолкнуло ученых на мысль о том, что животным снятся привычные действия, которые они совершают, когда бодрствуют. Исследователи Массачусетского университета Кенуэй Луис и Мэтью Уилсон провели эксперимент на крысах, бегающих по лабиринту в поисках пищи. Они записали активность нейронов в части крысиного мозга, отвечающую за память и формирование эмоций, во время реального бега и сна. В результате, схемы возбуждения нейронов в процессе бега и во время REM-фазы сна оказались очень похожи: складывалось впечатление, что и во сне крысы продолжают мысленно бежать по лабиринту.`,
        id: '120'
    }




]


export const backgroundArticles: IBackgroundArticle[] = [
    {
        name: 'некоторые высказывания великих людей о сне',
        content: `Артур Шопенгауэр: «Жизнь и сновидения — страницы одной и той же книги». В. Шекспир: «Сон — это чудо матери природы, вкуснейшее из блюд на земном пиру». \b И. М. Сеченов: «Сон — это небывалая комбинация былых впечатлений».`
    },
    {
        name: '',
        content: `Специалисты все еще пытаются понять, что именно происходит в мозге при погружении в сон и пробуждении. Александр Мельников объясняет на упрощенной модели: «Существует несколько центров бодрствования, расположенных ближе к стволу мозга и гипоталамусу. В их работе участвуют нейротрансмиттеры: серотонин, норадреналин, орексин. Им противостоит «центр сна», расположенный в передней части головного мозга, выделяющий гамма-аминомасляную кислоту, которая подавляет активность центров бодрствования. При пробуждениях, напротив, активируются нейроны бодрствования, подавляя нейроны сна». Специалист добавляет, что с точки зрения современной науки эта схема устарела и в реальности все еще сложнее.`
    }
    ,
    {
        name: 'цитата',
        content: `Гиппократ: «Сон и бессонница, то и другое сверх меры проявляющиеся, — худой знак».`
    }
]

export const user: IUser = {
    id: '123',
    name: 'user',
    email: 'tetst@test.ru',
    myDreams: ['205']
}