import { useNavigate } from "react-router-dom";
import style from "./Register.module.scss";

export const Register = () => {
  const navigate = useNavigate();
  const handleLogin = () : void => {
    navigate('/login', { state: { background: '/'}})
  }
  return (
    <>
      <form className={style.register}>
        <label htmlFor="registerName" className={style.register_label}>
          Ваше имя
        </label>
        <input
          type="text"
          id="registerName"
          name="registerName"
          className={style.register_input}
          required
          minLength={4}
          maxLength={16}
          placeholder="Введите имя"
        />

        <label htmlFor="registerPassword" className={style.register_label}>
          Придумайте пароль
        </label>
        <input
          type="password"
          id="registerPassword"
          name="registerPassword"
          className={style.register_input}
          required
          minLength={6}
          maxLength={28}
          placeholder="Минимум 6 знаков"
        />

        {/* TODO: make designer && mind about Button component ??? */}
        <button type="submit" className={style.register_button}>
          Зарегистрироватся
        </button>
        <span className={style.tip}>
          Есть аккаунт? <span onClick={handleLogin} className={style.link}>Войти</span>
        </span>
      </form>
    </>
  );
};
