import type { FC } from "react";
import style from "./Dream.module.scss";
import { useNavigate, useParams } from "react-router-dom";
import { dreams } from "../../api/mock";

export const Dream: FC = () => {
  const { id } = useParams(); 
  const navigate = useNavigate();
  const toProfie = () => {
    navigate('/profile', {state: {background: '/'}});
  }
  const item = dreams.find(item => id === item.id);
  return (
    <div className={style.dreamstory}>
      <h3 className={style.dreamstory_title}>{item?.name}</h3>
      <span className={style.dreamstory_text}>{item?.text}</span>
      <div className={style.dreamstory_footer}>
        <span className={style.dreamstory_footer_author}>
          {item?.author ? item.author : "Неизвестный автор"}
        </span>
        <span className={style.dreamstory_footer_date}>
          {item?.created_at.getFullYear()}/{item?.created_at.getDate()}/{item?.created_at.getMonth()} 
          {/* TODO: FIX THIS */}
        </span>
      </div>
      <div className={style.dreamstory_actions}>
        <button type="button" className={style.share_button}>
          Поделитесь
        </button>
        <button type="button" className={style.back_button} onClick={toProfie}>
          Назад в профиль
        </button>
      </div>
    </div>
  );
};
