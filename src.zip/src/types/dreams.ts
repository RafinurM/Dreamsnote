export interface IDream {
    author?: string;
    name: string;
    text: string;
    created_at: Date;
    id: string;
    likes: string[];
}