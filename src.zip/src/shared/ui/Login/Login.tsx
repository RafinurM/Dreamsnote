import type { FC } from "react";
import style from "./Login.module.scss";
import { useNavigate } from "react-router-dom";

export const Login: FC = () => {
  const navigate = useNavigate();
  const handleRegister = (): void => {
    navigate("/register", { state: { background: "/" } });
  };
  const handleForgot = (): void => {
    navigate("/forgot", { state: { background: "/" } });
  };
  return (
    <form className={style.login}>
      <label htmlFor="loginName" className={style.login_label}>
        Ваше имя
      </label>
      <input
        type="text"
        id="loginName"
        name="loginName"
        className={style.login_input}
        required
        minLength={4}
        maxLength={16}
        placeholder="Введите имя"
      />

      <label htmlFor="loginPassword" className={style.login_label}>
        Ваш пароль
      </label>
      <input
        type="password"
        id="loginPassword"
        name="loginPassword"
        className={style.login_input}
        required
        minLength={6}
        maxLength={28}
        placeholder="Введите пароль"
      />
      <button type="submit" className={style.login_button} >
        Войти
      </button>
      <span className={style.tip}>
        Нет аккаунта?{" "}
        <button className={style.link_button} onClick={handleRegister}>
          Зарегистрироватся
        </button>
      </span>
      <span className={style.tip}>
        Забыли пароль?{" "}
        <button className={style.link_button} onClick={handleForgot}>
          Восстановить пароль
        </button>
      </span>
    </form>
  );
};
