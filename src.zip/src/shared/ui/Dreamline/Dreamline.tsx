import { type FC, type SyntheticEvent } from "react";
import style from "./Dreamline.module.scss";
import clsx from "clsx";
import { changeCover } from "../../../store/use-app-store";
import { useNavigate } from "react-router-dom";
import { useDreams, useLikeDream } from "../../../store/use-dreams-store";
import { useUser } from "../../../store/use-user-store";

interface IDreamlineProps {
  isVisible: boolean;
}

export const Dreamline: FC<IDreamlineProps> = ({ isVisible }) => {
  const navigate = useNavigate();
  const user = useUser();
  const dreams = useDreams();
  const currentDream = dreams.length > 0 ? dreams[0] : undefined;
  const likeDream = useLikeDream();
  const changeDream = (e: SyntheticEvent): void => {
    e.preventDefault();
    e.stopPropagation();
  };
  const handleGoFull = (id: string): void => {
    navigate(`/profile/dreams/${id}`, { state: { background: "/" } });
  };
  if (!isVisible || !currentDream) return null;
  return (
    <div className={style.dreamline}>
      {isVisible && (
        <div className={style.dreamline_story}>
          <div className={style.dreamline_header}>
            <h4 className={style.dreamline_story_name}>{currentDream.name}</h4>
            <span className={style.dreamline_story_author}>
              {currentDream.author ? currentDream.author : ""}
            </span>
            <span className={style.dreamline_story_date}>
              {currentDream.created_at.getFullYear()}
            </span>
          </div>
          <span className={style.dreamline_story_text} onClick={changeDream}>
            {currentDream.text}
          </span>
          <div className={style.dreamline_footer}>
            <div className={style.dreamline_actions}>
              <button
                // like f
                onClick={() => likeDream(user.id, currentDream.id)}
                className={clsx(
                  style.dreamline_action,
                  style.dreamline_action_like
                )}
              >
                Нравится
              </button>
              <button
                onClick={() => handleGoFull(currentDream.id)}
                className={clsx(
                  style.dreamline_action,
                  style.dreamline_action_full
                )}
              >
                Читать полностью
              </button>
              <button
                onClick={() => changeCover()}
                className={clsx(
                  style.dreamline_action,
                  style.dreamline_action_back
                )}
              >
                Вернуться
              </button>
            </div>
            <span className={clsx(style.dreamline_likes)}>
              Likes: {currentDream.likes?.length ?? 0}
            </span>
          </div>
        </div>
      )}
    </div>
  );
};
