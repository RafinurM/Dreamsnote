export interface IBackgroundArticle {
    name: string;
    content: string;
    author?: string;
}