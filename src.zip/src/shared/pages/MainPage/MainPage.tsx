// import style from './MainPage.module.scss'; 

export const MainPage = () => {
    // const openModal = (): void => {};
    return (
        <>
        </>

    )
}