import { useState, type FC } from "react";
import style from "./DreamSender.module.scss";
import clsx from "clsx";
import { Dreamline } from "../Dreamline";
import { Cover } from "../Cover/Cover";

export const DreamSender: FC = () => {
  const [show, setShow] = useState(true);
  const [isVisible, setIsVisible] = useState(true);
  const handleToggle = (): void => {
    setShow((prev) => !prev);
    setIsVisible((prev) => !prev);
  };

  return (
    <>
      <div className={clsx(style.dream_sender, show && style.dream_closed)}>
        <h3 className={style.dream_header} onClick={handleToggle}>
          {isVisible ? `Отправить сон` : `Читать сны`}
          <div className={clsx(style.dream_header_container)}>
            <svg
              className={clsx(style.stroke)}
              xmlns="http://www.w3.org/2000/svg"
              width="40"
              height="40"
              fill="none"
              viewBox="0 0 24 24"
            >
              <path
                className={clsx(
                  style.stroke_up_act,
                  !show && style.stroke_active
                )}
                strokeWidth="2"
                d="m18 18-6-6-6 6M18 12l-6-6-6 6"
              />
            </svg>
            <svg
              className={clsx(style.stroke)}
              xmlns="http://www.w3.org/2000/svg"
              width="40"
              height="40"
              fill="none"
              viewBox="0 0 24 24"
            >
              <path
                className={clsx(
                  style.stroke_down_act,
                  show && style.stroke_active
                )}
                strokeWidth="2"
                d="m18 12-6 6-6-6M18 6l-6 6-6-6"
              />
            </svg>
          </div>
        </h3>
        <form className={clsx(style.form, show && style.form_closed)}>
          {/* <label htmlFor="dreamStory">Ваш сон</label> */}
          <div
            className={clsx(
              style.textarea_wrapper,
              show && style.textarea_closed
            )}
          >
            <textarea
              id="dreamStory"
              maxLength={1500}
              minLength={25}
              name="dreamText"
              required
              placeholder="Поделитесь своим сном со всем миром! Если вы что то конечно видите."
              className={clsx(style.dream_input, show && style._unactive)}
              spellCheck
            />
          </div>

          <button
            type="submit"
            className={clsx(
              style.dream_submit,
              show && style.dream_submit_closed
            )}
            disabled={show}
          >
            отправить
          </button>
        </form>
        {<Cover />}
        <Dreamline isVisible={isVisible} />
      </div>
    </>
  );
};
