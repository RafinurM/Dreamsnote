export interface IArticle {
    name: string;
    content: string;
    imageUrl?: string;
    id: string;
}