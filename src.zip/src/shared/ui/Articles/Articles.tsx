import { type FC } from "react";
import style from "./Articles.module.scss";
import clsx from "clsx";
import { useNavigate } from "react-router-dom";
import { articles, type IArticle } from "../../api/mock";
import { v4 as uuidv4 } from "uuid";

// interface IArticlesProps {
//   // onClick: () => void;
// }

export const Articles: FC = () => {
  const navigate = useNavigate();
  const handleClick = (id: string): void => {
    navigate(`/article/${id}`, { state: { background: "/" } });
  };
  return (
    <>
      <div className={style.articles}>
        {articles.map((article: IArticle) => {
          return (
            <button
              key={uuidv4()}
              onClick={() => handleClick(article.id)}
              className={clsx(style.acticle_title, style.article)}
            >
              <h3 className={style.article_name}>{article.name}</h3>
            </button>
          );
        })}
      </div>
    </>
  );
};
