import type { FC } from "react";
import style from "./Profile.module.scss";
import { dreams, user } from "../../api/mock";
import { v4 as uuidv4 } from "uuid";
import { useNavigate } from "react-router-dom";

export const Profile: FC = () => {
  const navigate = useNavigate();
  const handleClick = (id: string): void => {
    navigate(`/profile/dreams/${id}`, { state: { background: "/" } });
  };
  return (
    <>
      <div className={style.profile}>
        <span className={style.profile_name}>Имя: {user.name}</span>

        <span className={style.dreams}>Мои записи</span>
        <ul className={style.dreams_list}>
          {user.myDreams.map((id) => {
            const dream = dreams.find((item) => item.id === id);
            return (
              <li className={style.dreams_item} key={uuidv4()}>
                <button
                  className={style.dreams_item_link}
                  onClick={() => handleClick(id)}
                >
                  {dream.name ? dream?.name : ""}
                </button>
              </li>
            );
          })}
        </ul>
        <button className={style.logout}>выйти из профиля</button>
      </div>
    </>
  );
};
