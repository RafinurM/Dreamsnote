import { create, type StateCreator } from "zustand";
import { dreams } from "../shared/api/mock";
import type { IDream } from "../types/dreams";

interface IActions {
    addDream: (dream: IDream) => void;
    removeDream: (dream: IDream) => void;
    likeDream: (userId: string, dreamId: string) => void;
    // removeLike: (userId: string, dreamId: string) => void;
}

interface IInitialState {
    dreams: IDream[];
}

interface IDreamsStore extends IInitialState, IActions { }

const initialState: IInitialState = {
    dreams: dreams,
};

const dreamsStore: StateCreator<IDreamsStore> = (set) => ({
    ...initialState,
    addDream: (dream) =>
        set((state) => {
            if (state.dreams.includes(dream)) return state;
            return { dreams: [...state.dreams, dream] };
        }),
    removeDream: (dream) =>
        set((state) => ({
            dreams: state.dreams.filter((i) => i !== dream),
        })),
    likeDream: (userId, dreamId) =>
        set((state) => {
            const dreamsCopy = state.dreams.map((dream) => {
                if (dream.id === dreamId) {
                    const newLikes = dream.likes.includes(userId) ? dream.likes : [...dream.likes, userId];
                    return { ...dream, likes: newLikes };
                }
                return dream;
            });
            return { dreams: dreamsCopy };
        }),
});

const useDreamsStore = create<IDreamsStore>()(dreamsStore);

export const useDreams = () => useDreamsStore((state) => state.dreams);
export const useLikeDream = () => useDreamsStore((state) => state.likeDream);
